package com.netapp.employeemanagement.exception;

public class InvalidNameException extends Exception {

	@Override
	public String toString() {
		return "InvalidNameException ["+super.getMessage()+"]";
	}

	public InvalidNameException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
