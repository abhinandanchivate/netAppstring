package com.netapp.employeemanagement.exception;

public class InvalidSalaryException extends Exception {

	
	
	// when u want to create any user defined exception then
	// 1. override the toString method
	// 2. use super method which is accepting string this super method call 
	// will do it inside the constructor.
	
	public InvalidSalaryException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "InvalidSalaryException ["+super.getMessage()+"]";
	}
	

}
