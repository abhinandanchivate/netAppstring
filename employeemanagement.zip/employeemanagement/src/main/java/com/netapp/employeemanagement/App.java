package com.netapp.employeemanagement;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

import com.netapp.employeemanagement.exception.InvalidNameException;
import com.netapp.employeemanagement.exception.InvalidSalaryException;
import com.netapp.employeemanegement.bean.Employee;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		try {
			Employee employee = new Employee("ab001", "abhi", "chivate", "Pune", 123.00f);
		} catch (InvalidSalaryException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvalidNameException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
