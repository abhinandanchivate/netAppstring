package com.netapp.employeemanegement.bean;

import com.netapp.employeemanagement.exception.InvalidNameException;
import com.netapp.employeemanagement.exception.InvalidSalaryException;

public class Employee {
	
	private String empId;
	public Employee() {
		super();
	}
	public Employee(String empId, String empFirstName, String empLastName, String empAddress, float empSalary) throws InvalidSalaryException, InvalidNameException {
		super();
		this.empId = empId;
		this.setEmpFirstName(empFirstName);
		this.empLastName = empLastName;
		this.empAddress = empAddress;
		this.setEmpSalary(empSalary);
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empFirstName=" + empFirstName + ", empLastName=" + empLastName
				+ ", empAddress=" + empAddress + ", empSalary=" + empSalary + "]";
	}
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getEmpFirstName() {
		return empFirstName;
	}
	public void setEmpFirstName(String empFirstName) throws InvalidNameException {
		if(empFirstName.length()==0) {
			throw new InvalidNameException("Name should be blank");
		}
		else if(empFirstName.length()>0&& empFirstName.length()<=2) {
			throw new InvalidNameException("Name should be between 4 to 8 chrs");
		}
		else
		this.empFirstName = empFirstName;
	}
	public String getEmpLastName() {
		return empLastName;
	}
	public void setEmpLastName(String empLastName) {
		this.empLastName = empLastName;
	}
	public String getEmpAddress() {
		return empAddress;
	}
	public void setEmpAddress(String empAddress) {
		this.empAddress = empAddress;
	}
	public float getEmpSalary() {
		return empSalary;
	}
	public void setEmpSalary(float empSalary) throws InvalidSalaryException {
		
		if(empSalary<=0) {
			// we have to handle the situation
			// throws
			throw new InvalidSalaryException("salary should not be negative");
		}
		else 
		this.empSalary = empSalary;
	}
	private String empFirstName;
	private String empLastName;
	private String empAddress;
	private float empSalary;
	

}
